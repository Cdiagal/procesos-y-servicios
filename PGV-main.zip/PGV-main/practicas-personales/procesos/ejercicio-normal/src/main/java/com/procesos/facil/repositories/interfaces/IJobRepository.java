package com.procesos.facil.repositories.interfaces;

public interface IJobRepository {
    public boolean add(String texto);
}
