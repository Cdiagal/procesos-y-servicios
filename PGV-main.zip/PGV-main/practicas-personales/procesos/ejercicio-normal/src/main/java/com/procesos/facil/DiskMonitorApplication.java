package com.procesos.facil;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DiskMonitorApplication {
    
    public static void main(String[] args) {
        SpringApplication.run(DiskMonitorApplication.class, args);
    }
}
