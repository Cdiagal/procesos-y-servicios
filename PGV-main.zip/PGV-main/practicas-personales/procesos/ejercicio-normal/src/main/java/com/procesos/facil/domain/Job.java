package com.procesos.facil.domain;

public enum Job {
    DF,DU
}
