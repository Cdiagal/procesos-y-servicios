package com.docencia.semaforo;

public class SaiyanRaceSemaphoreOne implements Runnable {
    

    @Override
    public void run() {
        
    }

    public static void main(String[] args) throws InterruptedException {

    }
}
