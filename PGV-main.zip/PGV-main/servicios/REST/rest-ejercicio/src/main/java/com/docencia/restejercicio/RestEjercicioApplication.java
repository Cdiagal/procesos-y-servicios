package com.docencia.restejercicio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestEjercicioApplication {

    public static void main(String[] args) {
        SpringApplication.run(RestEjercicioApplication.class, args);
    }
}
