package com.docencia.tareas.service;

import java.util.List;

import com.docencia.tareas.model.Alumno;

public interface IAlumnoService {
    List<Alumno> listarTodas();
}
