package org.formacion.procesos.domain;

public enum ProcessType {
    PS,LS
}
