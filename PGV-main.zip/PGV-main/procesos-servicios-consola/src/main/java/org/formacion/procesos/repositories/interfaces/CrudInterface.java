package org.formacion.procesos.repositories.interfaces;

public interface CrudInterface {
    public boolean add(String texto);
    
}
