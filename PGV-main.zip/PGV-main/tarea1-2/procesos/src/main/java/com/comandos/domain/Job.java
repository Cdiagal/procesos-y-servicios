package com.comandos.domain;

public enum Job {
    LSOF, TOP, PS
}
